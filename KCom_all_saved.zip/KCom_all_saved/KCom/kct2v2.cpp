/*

This program is a function based version of kct2.cpp - this ensures that the functional form of kct2.cpp
is implemented correctly by establishing that the same functionality of kct2.cpp can be achieved with this function based version.

21.7.2017
Grant Giesbrecht

*/

// http://www.cmrr.umn.edu/~strupp/serial.html#basics

#include <stdio.h>   /* Standard input/output definitions */
#include <string.h>  /* String function definitions */
#include <unistd.h>  /* UNIX standard function definitions */
#include <fcntl.h>   /* File control definitions */
#include <errno.h>   /* Error number definitions */
#include <termios.h> /* POSIX terminal control definitions */
#include <unistd.h>
#include <iostream>
#include <chrono>

using namespace std;

bool pingMCU(int fd, float f_out, float& f_in, float wait_time=1);

int main(){

    /*******************************************************************
    ************************** OPEN FILE *******************************
    *******************************************************************/

    int fd; //File descriptor

    // Open file
    fd = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY); //Open file - O_RDWR = read + write, O_NCTTY means don't become controlling proceess (problem with keybord input or something), O_NDELAY means try to be non-blocking
    if (fd == -1){
        cout << strerror(errno) << endl; //Print the error if failed to open
        return -1;
    }else{
        cout << "Connection successful" << endl;
    }

    cout << "Waiting for MCU... \t" << std::flush;
    usleep(2e6);
    cout << "Complete" << endl;

    fcntl(fd, F_SETFL, 0); //unset all file status flags

    /********************S**** ADJUST SETTINGS *************************/

    struct termios settings;
    tcgetattr(fd, &settings);
    
    settings.c_cflag |= CREAD; //Ensure recieving is enabled
    settings.c_cflag |= CLOCAL; //Ensure program doesn't take ownership of port

    speed_t spd;

    cfsetispeed(&settings, B115200);
    cfsetospeed(&settings, B115200);

    tcsetattr(fd, TCSANOW, &settings);

    fcntl(fd, F_SETFL, FNDELAY);

    /*******************************************************************
    ********************* SEND & RECIEVE FLOAT *************************
    *******************************************************************/

    //Prepare variables
    float x = 1;
    float y;
    unsigned char c;
    int check_code;
    chrono::high_resolution_clock::time_point t_begin;
    chrono::duration<double> time_span;
    ssize_t nbw;

    while (true){ //infinite loop

        if (pingMCU(fd, x, y)){
            cout << "MAIN LOOP: Success!\n\tSent: " << x << " Received: " << y << endl;
        }else{
            cout << "MAIN LOOP: Failed" << endl;
        }

        x += .5;

        // usleep(1e6);
    }

    close(fd);

    return 0;
}

/*
Send a float to the MCU connected to 'fd' and returns a float

PARAMETERS:
    fd - file descriptor to which to write
    f_out - float to send out to MCU
    f_in - float to read in from MCU
    wait_time - time for which to wait for MCU to send synchronization code

Returns true if successful
*/
bool pingMCU(int fd, float f_out, float& f_in, float wait_time){

    //Prepare variables
    float x = f_out;
    float y;
    unsigned char c;
    int check_code;
    chrono::high_resolution_clock::time_point t_begin;
    chrono::duration<double> time_span;
    ssize_t nbw;

    //Send float to MCU
    write(fd, &x, 4);
    
    check_code = 0;
    
    //Wait for 'wait_time' to read synchronization sequence
    t_begin = chrono::high_resolution_clock::now();
    time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
    while (time_span.count() < wait_time){ //Wait one second
        if (read(fd, &c, 1) == 1){
            // cout << "Read: " << (int)c << endl;
            if (c == 255){
                check_code++;
                if (check_code == 5){ //Break if 5 synchronization bytes are read
                    cout << "Synchronization Success!" << endl;
                    break;
                }
            }else{
                check_code = 0;
            }
        }
        time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
    }

    if (check_code == 5){
        
        //Wait for 'wait_time' to read synchronization sequence
        t_begin = chrono::high_resolution_clock::now();
        time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
        bool success = false;
        while (time_span.count() < wait_time){ //Wait one second
            if (read(fd, &y, 4) == 4){
                f_in = y;
                cout << "Received: " << f_in << endl;
                success = true;
                break;
            }else if(f_in > 0){
                return false;
            }
            time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
        }
        if (!success){
            cout << "Timed out waiting for float" << endl;
            return false;
        }
        

    }else{
        cout << "Timed out waiting for synchronization packet" << endl;
    }

    // f_in = y;
    return true;
}

















