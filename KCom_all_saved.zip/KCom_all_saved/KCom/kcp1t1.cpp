#include "kcp1.hpp"
#include <iostream>
#include <vector>
#include <stdio.h>
#include <errno.h>
#include <string.h>


using namespace std;

int main(){

    KComP1 mcu("/dev/ttyUSB0", 9600);
    if (!mcu.is_open()){
        cout << "\tERROR: Failed to open device" << endl << "\t\tError Code: " << strerror(errno) << endl;
    }else{
        cout << "Connected to device" << endl;
    }

    char buffer[11];
    buffer[11] = '\0';

    while(true){
        usleep(5e5);
        if (mcu.receive_buffer((void*)buffer, 10)){
            cout << "Read successfully!" << endl << "\tReceived: " << buffer << endl;
        }else{
            cout << "I got nothing..." << endl;
        }
    }

    return 0;
}