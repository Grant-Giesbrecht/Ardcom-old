#include <stdio.h>   /* Standard input/output definitions */
#include <string.h>  /* String function definitions */
#include <unistd.h>  /* UNIX standard function definitions */
#include <fcntl.h>   /* File control definitions */
#include <errno.h>   /* Error number definitions */
#include <termios.h> /* POSIX terminal control definitions */
#include <unistd.h>
#include <iostream>
#include <chrono>

using namespace std;

/*
Send a float to the MCU connected to 'fd' and returns a float

PARAMETERS:
    fd - file descriptor to which to write
    f_out - float to send out to MCU
    f_in - float to read in from MCU
    wait_time - time for which to wait for MCU to send synchronization code

Returns true if successful
*/
bool pingMCU(int fd, float f_out, float& f_in, float wait_time){

    //Prepare variables
    float x = f_out;
    float y;
    unsigned char c;
    int check_code;
    chrono::high_resolution_clock::time_point t_begin;
    chrono::duration<double> time_span;
    ssize_t nbw, nbr;

    //Send float to MCU
    write(fd, &x, 4);
    
    check_code = 0;
    
    //Wait for 'wait_time' to read synchronization sequence
    t_begin = chrono::high_resolution_clock::now();
    time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
    while (time_span.count() < wait_time){ //Wait one second
        if (read(fd, &c, 1) == 1){
            // cout << "Read: " << (int)c << endl;
            if (c == 255){
                check_code++;
                if (check_code == 5){ //Break if 5 synchronization bytes are read
                    cout << "Synchronization Success!" << endl;
                    break;
                }
            }else{
                check_code = 0;
            }
        }
        time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
    }

    if (check_code == 5){
        
        //Wait for 'wait_time' to read float
        t_begin = chrono::high_resolution_clock::now();
        time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
        bool success = false;
        while (time_span.count() < wait_time){ //Wait one second
            nbr = read(fd, &y, 4);
            if (nbr == 4){
                f_in = y;
                cout << "Received: " << f_in << endl;
                success = true;
                break;
            }else if(nbr > 0){
                return false;
            }
            time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
        }
        if (!success){
            cout << "Timed out waiting for float" << endl;
            return false;
        }
        

    }else{
        cout << "Timed out waiting for synchronization packet" << endl;
        return false;
    }

    // f_in = y;
    return true;
}

/*
Inquires the value of a parameter saved on the MCU descibed by 'fd'.

PARAMETERS:
    fd - file descriptor of MCU
    param - parameter to read
    buffer - buffer in which to save read parameter
    buf_size - size of buffer (must be synchronized with MCU-side program)
    wait_time - time for which to wait for synchronization packet and the buffer

Returns true if successful
*/
bool inquireMCU(int fd, char param, void* buffer, unsigned int buf_size, int wait_time){

    char local_param = param;
    // char read_buffer[11];
    // read_buffer[11] = '\0';
    ssize_t nbr, nbw;
    chrono::high_resolution_clock::time_point t_begin;
    chrono::duration<double> time_span;
    int check_code;
    unsigned char c;

    nbw = write(fd, &local_param, 1); //Send param to read

    //Wait one second to read synchronization sequence
    check_code = 0;
    t_begin = chrono::high_resolution_clock::now();
    time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
    while (time_span.count() < wait_time){ //Wait one second
        if (read(fd, &c, 1) == 1){
            // cout << "Read: " << (int)c << endl;
            if (c == 255){
                check_code++;
                // cout << "255! \t" << check_code  << endl;
                if (check_code == 5){ //Break if 5 synchronization bytes are read
                    cout << "Synchronization Success!" << endl;
                    break;
                }
            }else{
                check_code = 0;
            }
        }
        time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
    }
    if (check_code == 5){
        
        //Wait for 'wait_time' to read parameter
        t_begin = chrono::high_resolution_clock::now();
        time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
        bool success = false;
        while (time_span.count() < wait_time){ //Wait one second
            nbr = read(fd, buffer, buf_size);
            if (nbr == buf_size){
                cout << "\tGot it!" << endl;
                success = true;
                break;
            }else if(nbr > 0){
                return false;
            }
            time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
        }
        if (!success){
            cout << "Timed out waiting for parameter" << endl;
            return false;
        }

    }else{
        cout << "Timed out" << endl;
        return false;
    }

    return true;
}