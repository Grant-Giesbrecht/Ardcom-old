#ifndef _KCOMFN_HPP_
#define _KCOMFN_HPP_

bool pingMCU(int fd, float f_out, float& f_in, float wait_time);

bool inquireMCU(int fd, char param, void* buffer, unsigned int buf_size, int wait_time=1);

#endif