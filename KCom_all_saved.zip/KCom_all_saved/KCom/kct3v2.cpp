/*

This program is function-based version of 'kct3.cpp'. It adds an inquisition function and
establishes that it operates correctly.

21.7.2017
Grant Giesbrecht

*/


// http://www.cmrr.umn.edu/~strupp/serial.html#basics

#include <stdio.h>   /* Standard input/output definitions */
#include <string.h>  /* String function definitions */
#include <unistd.h>  /* UNIX standard function definitions */
#include <fcntl.h>   /* File control definitions */
#include <errno.h>   /* Error number definitions */
#include <termios.h> /* POSIX terminal control definitions */
#include <unistd.h>
#include <iostream>
#include <chrono>

// #include "KComFn1.hpp"

using namespace std;

bool inquireMCU(int fd, char param, void* buffer, unsigned int buf_size, int wait_time=1);

int main(){

    /*******************************************************************
    ************************** OPEN FILE *******************************
    *******************************************************************/

    int fd; //File descriptor

    // Open file
    fd = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY); //Open file - O_RDWR = read + write, O_NCTTY means don't become controlling proceess (problem with keybord input or something), O_NDELAY means try to be non-blocking
    if (fd == -1){
        cout << strerror(errno) << endl; //Print the error if failed to open
        return -1;
    }else{
        cout << "Connection successful" << endl;
    }

    cout << "Waiting for MCU... \t" << std::flush;
    usleep(2e6);
    cout << "Complete" << endl;

    fcntl(fd, F_SETFL, 0); //unset all file status flags

    /********************S**** ADJUST SETTINGS *************************/

    struct termios settings;
    tcgetattr(fd, &settings);
    
    settings.c_cflag |= CREAD; //Ensure recieving is enabled
    settings.c_cflag |= CLOCAL; //Ensure program doesn't take ownership of port

    speed_t spd;

    cfsetispeed(&settings, B115200);
    cfsetospeed(&settings, B115200);

    tcsetattr(fd, TCSANOW, &settings);

    fcntl(fd, F_SETFL, FNDELAY);

    /*******************************************************************
    ************************** READ PARAM ******************************
    *******************************************************************/

    // //Set read to non-blocking operation
    // fcntl(fd, F_SETFL, FNDELAY);

    //Create buffer
    char read_buffer[11];
    read_buffer[11] = '\0';
    ssize_t nbr, nbw;
    chrono::high_resolution_clock::time_point t_begin;
    chrono::duration<double> time_span;
    int check_code;
    unsigned char c;

    char param = 0x01;

    while (true){

        usleep(5e5);

        char buffer[11];
        buffer[10] = '\0';

        if (!inquireMCU(fd, 0x01, buffer, 10)){
            cout << "MAIN LOOP: Failed" << endl;
        }else{
            cout << "MAIN LOOP: Success!\n\t" << "Received: " << buffer << endl;
        }

        // nbw = write(fd, &param, 1); //Send param to read

        // //Wait one second to read synchronization sequence
        // check_code = 0;
        // t_begin = chrono::high_resolution_clock::now();
        // time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
        // while (time_span.count() < 1){ //Wait one second
        //     if (read(fd, &c, 1) == 1){
        //         // cout << "Read: " << (int)c << endl;
        //         if (c == 255){
        //             check_code++;
        //             // cout << "255! \t" << check_code  << endl;
        //             if (check_code == 5){ //Break if 5 synchronization bytes are read
        //                 cout << "Synchronization Success!" << endl;
        //                 break;
        //             }
        //         }else{
        //             check_code = 0;
        //         }
        //     }
        //     time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
        // }
        // if (check_code == 5){
            
        //     //Read buffer
        //     nbr = read(fd, read_buffer, 10);
        //     if (nbr == -1){
        //         cout << '\t' << strerror(errno) << endl;
        //     }else if(nbr == 0){
        //         cout << "\tNo data avaialble" << endl;
        //     }else if(nbr == 10){
        //         cout << "Read 10 bytes" << endl;
        //         cout << "\t" << read_buffer << endl;
        //     }else{
        //         cout << "\tOnly read " << nbr << " bytes." << endl;
        //     }

        // }else{
        //     cout << "Timed out" << endl;
        // }

        
    }

    close(fd);

    return 0;
}

/*
Inquires the value of a parameter saved on the MCU descibed by 'fd'.

PARAMETERS:
    fd - file descriptor of MCU
    param - parameter to read
    buffer - buffer in which to save read parameter
    buf_size - size of buffer (must be synchronized with MCU-side program)
    wait_time - time for which to wait for synchronization packet and the buffer

Returns true if successful
*/
bool inquireMCU(int fd, char param, void* buffer, unsigned int buf_size, int wait_time){

    char local_param = param;
    // char read_buffer[11];
    // read_buffer[11] = '\0';
    ssize_t nbr, nbw;
    chrono::high_resolution_clock::time_point t_begin;
    chrono::duration<double> time_span;
    int check_code;
    unsigned char c;

    nbw = write(fd, &local_param, 1); //Send param to read

    //Wait one second to read synchronization sequence
    check_code = 0;
    t_begin = chrono::high_resolution_clock::now();
    time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
    while (time_span.count() < wait_time){ //Wait one second
        if (read(fd, &c, 1) == 1){
            // cout << "Read: " << (int)c << endl;
            if (c == 255){
                check_code++;
                // cout << "255! \t" << check_code  << endl;
                if (check_code == 5){ //Break if 5 synchronization bytes are read
                    cout << "Synchronization Success!" << endl;
                    break;
                }
            }else{
                check_code = 0;
            }
        }
        time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
    }
    if (check_code == 5){
        
        //Wait for 'wait_time' to read parameter
        t_begin = chrono::high_resolution_clock::now();
        time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
        bool success = false;
        while (time_span.count() < wait_time){ //Wait one second
            nbr = read(fd, buffer, buf_size);
            if (nbr == buf_size){
                cout << "\tGot it!" << endl;
                success = true;
                break;
            }else if(nbr > 0){
                return false;
            }
            time_span = chrono::duration_cast<chrono::duration<double> >( chrono::high_resolution_clock::now() - t_begin);
        }
        if (!success){
            cout << "Timed out waiting for parameter" << endl;
            return false;
        }

    }else{
        cout << "Timed out" << endl;
        return false;
    }

    return true;
}






























