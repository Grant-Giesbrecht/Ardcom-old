#include <stdio.h>   /* Standard input/output definitions */
#include <string.h>  /* String function definitions */
#include <unistd.h>  /* UNIX standard function definitions */
#include <fcntl.h>   /* File control definitions */
#include <errno.h>   /* Error number definitions */
#include <termios.h> /* POSIX terminal control definitions */
#include <unistd.h>
#include <iostream>
#include <string>

#ifndef _KCOMP1_HPP_
#define _KCOMP1_HPP_

//Transmission Mode Codes
#define FN_VERIFY 0x01
#define FN_INQUIRY 0x04
#define FN_SET 0x02
#define FN_PING 0x03

//Transmission Value Codes
#define VAL_ACK 0x0A
#define VAL_NAK 0x15

class KComP1{
public:

    //Initializer
    KComP1();
    KComP1(std::string port);
    KComP1(std::string port, int baudrate);
    bool open_device(std::string port);
    bool open_device(std::string port, int baudrate);
    bool is_open();
    void close();

    //Auxilliary initializing commands
    void wait_for_MCU(double seconds);
    bool verify_connection();

    //Primary communication functions   
    void read_MCU_parameter(char parameter, float& value);
    void set_MCU_parameter(char parameter, float value);
    void ping_float(char parameter, float send, float& recieve);

    //Send functions
    unsigned int send_buffer(void* buffer, int nbytes);
    bool send_float(float x);
    bool send_char(char c);
    bool send_int(int i);

    //Recive functions
    unsigned int receive_buffer(void* buffer, int nbytes);
    bool receive_float(float& x);
    bool receive_char(char& c);
    bool receive_int(int& i);

private:

    int fd;

    bool is_open_bool;
    int max_retries;
    int retry_delay;

};

// std::string prompt_avail_USB(std::string indentation);

#endif