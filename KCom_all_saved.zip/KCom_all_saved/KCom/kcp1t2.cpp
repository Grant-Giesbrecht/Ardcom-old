#include "kcp1.hpp"
#include <iostream>
#include <vector>
#include <stdio.h>
#include <errno.h>
#include <string.h>

using namespace std;

int main(){

    KComP1 mcu("/dev/ttyUSB0", 9600);
    if (!mcu.is_open()){
        cout << "\tERROR: Failed to open device" << endl << "\t\tError Code: " << strerror(errno) << endl;
    }else{
        cout << "Connected to device" << endl;
    }

    char buffer[] = {'2', '3', '4', '2', '4'};

    while(true){
        if (mcu.send_buffer((void*)buffer, 5)){
            cout << "Sent successfully!" << endl; // << "\tReceived: " << buffer << endl;
        }else{
            cout << "\tOops, failed to send :(" << endl;
        }
        usleep(5e6);
    }

    return 0;
}