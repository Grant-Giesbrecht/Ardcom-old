#include "kcp1.hpp"
#include <iostream>
#include <vector>
#include <stdio.h>
#include <errno.h>
#include <string.h>

using namespace std;

int main(){

    KComP1 mcu("/dev/ttyUSB0", B9600);
    if (!mcu.is_open()){
        cout << "\tERROR: Failed to open device" << endl << "\t\tError Code: " << strerror(errno) << endl;
        return -1;
    }else{
        cout << "Connected to device" << endl;
    }

    mcu.wait_for_MCU(2);

    if (mcu.verify_connection()){
        cout << "Connection confirmed" << endl;
    }else{
        cout << "Verification failed!" << endl;
        return -1;
    }

    

    char buffer[] = {'2', '3', '4', '2', '4'};

    float x;
    mcu.read_MCU_parameter(0x01, x);
    cout << "P: " << x << endl;
    mcu.set_MCU_parameter(0x01, 1);
    mcu.read_MCU_parameter(0x01, x);
    cout << "P: " << x << endl;

    // while(true){
    //     if (mcu.send_buffer((void*)buffer, 5)){
    //         cout << "Sent successfully!" << endl; // << "\tReceived: " << buffer << endl;
    //     }else{
    //         cout << "\tOops, failed to send :(" << endl;
    //     }
    //     usleep(5e6);
    // }

    return 0;
}