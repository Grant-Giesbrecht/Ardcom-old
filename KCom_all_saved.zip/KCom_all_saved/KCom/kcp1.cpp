#include "kcp1.hpp"

using namespace std;

KComP1::KComP1(){
    max_retries = 1000;
    retry_delay = 5000; //us
    is_open_bool = false;
}

KComP1::KComP1(string port){
    max_retries = 1000;
    retry_delay = 5000; //us
    is_open_bool = KComP1::open_device(port);
}

KComP1::KComP1(string port, int baudrate){
    is_open_bool = KComP1::open_device(port, baudrate);
}

bool KComP1::open_device(std::string port){
    return KComP1::open_device(port, B9600);
}

bool KComP1::open_device(string port, int baudrate){

    // Open file
    KComP1::fd = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY); //Open file - O_RDWR = read + write, O_NCTTY means don't become controlling proceess (problem with keybord input or something), O_NDELAY means try to be non-blocking
    if (fd == -1){
        is_open_bool = false;
        return false;
    }

    is_open_bool = true;

    fcntl(fd, F_SETFL, 0); //unset all file status flags

    /************************ ADJUST SETTINGS *************************/

    struct termios settings;
    tcgetattr(fd, &settings);
    
    settings.c_cflag |= CREAD; //Ensure recieving is enabled
    settings.c_cflag |= CLOCAL; //Ensure program doesn't take ownership of port

    speed_t spd;

    cfsetispeed(&settings, baudrate);
    cfsetospeed(&settings, baudrate);

    tcsetattr(fd, TCSANOW, &settings);  

    //Set read to non-blocking operation
    fcntl(fd, F_SETFL, FNDELAY);

    return true;
}

bool KComP1::is_open(){
    return KComP1::is_open_bool;
}

void KComP1::wait_for_MCU(double seconds){

    seconds = ((int)(seconds * 10))/10;

    long delay = 50000*seconds;

    cout << "Waiting for MCU |                     |\rWaiting for MCU  |" << std::flush;
    for (int i = 0 ; i < 20 ; i++){
        usleep(delay); //Sleep 100 ms
        cout << "=" << std::flush;
    }
    cout << endl << "MCU Ready" << endl;

}

bool KComP1::verify_connection(){

    if (!send_char(FN_VERIFY)){
         cout << "Failed to send" << endl;
    }else{
        cout << "SUCCESS" << endl;
    } 

    char x = 47;
    if (!receive_char(x)){
        cout << "Failed to receive" << endl;
    }else{
        cout << "Success" << endl;
    }

    if (x != VAL_ACK){
         cout << (int)x << endl;
         return false;
    }

    return true;

}

void KComP1::read_MCU_parameter(char parameter, float& value){

    bool success;
    if (!send_char(FN_INQUIRY)){
        cout << "FREAD1" << endl;
    }
    if (!send_char(parameter)){
        cout << "FREAD2" << endl;
    }
    if (!receive_float(value)){
        cout << "FREAD3" << endl;
    }

}

void KComP1::set_MCU_parameter(char parameter, float value){

    bool success;
    success = send_char(FN_SET);
    success = success && send_char(parameter);
    success = success && send_float(value);
    if (success){
        cout << "Successfully set MCU param" << endl;
    }else{
        cout << "Set MCU param FAILED" << endl;
    }

}

void KComP1::ping_float(char parameter, float send, float& receive){

    bool success;
    success = send_char(FN_PING);
    success = success && send_char(parameter);
    success = success && send_float(send);
    for (int i = 0 ; i < 20; i++){
        if (receive_float(receive)){
            return;
        } 
    }

    if (success){
        cout << "Successfully set MCU param" << endl;
    }else{
        cout << "Set MCU param FAILED" << endl;
    }

    receive = -1;
}

unsigned int KComP1::send_buffer(void* buffer, int nbytes){

    ssize_t nbw;
    nbw = write(KComP1::fd, buffer, nbytes);
    return (unsigned int)nbw;

}

bool KComP1::send_float(float x){

    if (sizeof(float) != 4) return false;

    return (send_buffer((void*) &x, 4) == 4);
}

bool KComP1::send_char(char c){

    if (sizeof(char) != 1) return false;

    return (send_buffer((void*)&c, 1) == 1);
}

bool KComP1::send_int(int i){

    if (sizeof(int) != 4) return false;

    return ( send_buffer((void*)&i, 4) == 4);
}

unsigned int KComP1::receive_buffer(void* buffer, int nbytes){

    return (unsigned int)read(KComP1::fd, buffer, nbytes);
}

bool KComP1::receive_float(float& x){

    float float_buf;

    /*ssize_t nbr;
    nbr = read(fd, &float_buf, 4);
    if (nbr == 4){
        x = float_buf;
        return true;
    }else{
        cout << "\tFirst failed " << nbr << endl;
        ssize_t nbr_total = 0;
        if (nbr != -1){ss
Connection confirmed
	First failed -1
	All failed
FREAD3
P: 1.4013e-
             nbr_total = nbr;
        }
        for (int i = 0 ; i < max_retries ; i++){
            usleep(retry_delay);
            cout << i << endl;
            nbr = read(fd, ((char*)(&float_buf)+nbr_total), (4-nbr_total));
            if (nbr >= -1) nbr_total += nbr;
            if (nbr_total >= 4){
                x = float_buf;
                cout << "Iterations: " << i << endl;
                return true;
            }
        }
    }*/

    /*ssize_t nbr;
    char reconstruction_buffer[4];
    nbr = read(fd, &reconstruction_buffer, 4);
    if (nbr == 4){
        memcpy(&float_buf, reconstruction_buffer, 4);
        x = float_buf;
        return true;
    }else{
        cout << "\tFirst failed " << nbr << endl;
        ssize_t nbr_total = 0;
        if (nbr != -1) nbr_total = nbr;
        for (int i = 0 ; i < max_retries ; i++){
            usleep(retry_delay);
            cout << i << endl;
            nbr = read(fd, (reconstruction_buffer+nbr_total), (4-nbr_total));
            if (nbr >= -1) nbr_total += nbr;
            if (nbr_total >= 4){
                memcpy(&float_buf, reconstruction_buffer, 4);
                x = float_buf;
                cout << "Iterations: " << i << endl;
                return true;
            }
        }
    }*/

    ssize_t nbr = 0;
    nbr = read(fd, &float_buf, 4);
    if (nbr == 4){
        x = float_buf;
        return true;
    }else{
        cout << "\tFirst failed " << nbr << endl;
        for (int i = 0 ; i < max_retries ; i++){
            usleep(retry_delay);
            cout << i << endl;
            nbr = read(fd, &float_buf, 4);
            if (nbr == 4){
                x = float_buf;
                cout << "Iterations: " << i << endl;
                return true;
            }
        }
    }

    cout << "\tAll failed" << endl;
    return false;

}

bool KComP1::receive_char(char& c){

    char char_buf = 41;

    ssize_t nbr;
    nbr = read(fd, &char_buf, 1);
    if (nbr == 1){
        c = char_buf;
        return true;
    }else{
        for (int i = 0 ; i < max_retries ; i++){
            usleep(retry_delay);
            nbr = read(fd, &char_buf, (1));
            if (nbr == 1){
                c = char_buf;
                return true;
            }
        }
    }

    return false;

}

bool KComP1::receive_int(int& i){
    
    int int_buf;

    ssize_t nbr;
    nbr = read(fd, &int_buf, 4);
    if (nbr == 4){
        i = int_buf;
        return true;
    }else{
        ssize_t nbr_total = 0;
        if (nbr != -1) nbr_total = nbr;
        for (int i = 0 ; i < max_retries ; i++){
            usleep(retry_delay);
            nbr = read(fd, (&int_buf+nbr_total), (4-nbr_total));
            if (nbr != -1) nbr_total += nbr;
            if (nbr_total >= 4){
                i = int_buf;
                return true;
            }
        }
    }

    return false;
}























// string prompt_avail_USB(string indentation){

    // string input;

    // //Find available USB ports
	// vector<string> ports;
	// Ardcom test0;
	// if (test0.open("/dev/ttyUSB0")){
	// 	ports.push_back("/dev/ttyUSB0");
	// 	test0.close();
	// }


	// Ardcom test1;
	// if (test1.open("/dev/ttyUSB1")){
	// 	ports.push_back("/dev/ttyUSB1");
	// 	test1.close();
	// }

    // Ardcom test4;
	// if (test4.open("/dev/ttyUSB2")){
	// 	ports.push_back("/dev/ttyUSB2");
	// 	test4.close();
	// }


	// Ardcom test2;
	// if (test2.open("/dev/ttyACM0")){
	// 	ports.push_back("/dev/ttyACM0");
	// 	test2.close();
	// }


	// Ardcom test3;
	// if (test3.open("/dev/ttyACM1")){
	// 	ports.push_back("/dev/ttyACM1");
	// 	test3.close();
	// }

    // Ardcom test5;
	// if (test5.open("/dev/ttyACM2")){
	// 	ports.push_back("/dev/ttyACM2");
	// 	test5.close();
	// }

	// //List available ports and read user selection
	// if (ports.size() == 0){
	// 	cout << indentation << "No devices found." << endl;
	// 	return "NO_PORT";
	// }

	// //Propmt user to select port
    // cout << indentation << "Select a port to which to attach..." << endl;
	// int a;
    // bool success;
	// do{
	// 	for (int i = 0 ; i < ports.size() ; i++){
	// 		cout << i << "). " << ports[i] << endl;
	// 	}
	// 	cout << indentation << endl << "Port: ";
	// 	getline(cin, input);
    //     if (input == "x" || input == "X") break;
    //     a = (int)strtod(input, &success);
    //     if (!success) continue;
	// }while(a >= ports.size());

	// //Check if user entered x (to exit)
	// if (input == "x"){
	// 	cout << indentation << "Exiting" << endl;
	// 	return "BAD_PORT";
	// }

//     return ports[a];
// }