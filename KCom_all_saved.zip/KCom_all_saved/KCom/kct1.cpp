// http://www.cmrr.umn.edu/~strupp/serial.html#basics

#include <stdio.h>   /* Standard input/output definitions */
#include <string.h>  /* String function definitions */
#include <unistd.h>  /* UNIX standard function definitions */
#include <fcntl.h>   /* File control definitions */
#include <errno.h>   /* Error number definitions */
#include <termios.h> /* POSIX terminal control definitions */
#include <unistd.h>
#include <iostream>

using namespace std;

int main(){

    /*******************************************************************
    ************************** OPEN FILE *******************************
    *******************************************************************/

    int fd; //File descriptor

    // Open file
    fd = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY); //Open file - O_RDWR = read + write, O_NCTTY means don't become controlling proceess (problem with keybord input or something), O_NDELAY means try to be non-blocking
    if (fd == -1){
        cout << strerror(errno) << endl; //Print the error if failed to open
        return -1;
    }else{
        cout << "Connection successful" << endl;
    }

    fcntl(fd, F_SETFL, 0); //unset all file status flags

    /********************S**** ADJUST SETTINGS *************************/

    struct termios settings;
    tcgetattr(fd, &settings);
    
    settings.c_cflag |= CREAD; //Ensure recieving is enabled
    settings.c_cflag |= CLOCAL; //Ensure program doesn't take ownership of port

    speed_t spd;
    // speed_t spd = cfgetispeed(&settings);
    // cout << "Default speeds: " << spd;
    // spd = cfgetospeed(&settings);
    // cout << " " << spd << endl;

    cfsetispeed(&settings, B115200);
    cfsetospeed(&settings, B115200);

    tcsetattr(fd, TCSANOW, &settings);

    /*******************************************************************
    ***************************** WRITE ********************************
    *******************************************************************/

    /*char buffer[] = {'2', '3', '4', '2', '4'};
    ssize_t nbw;

    while (true){
        usleep(1e6);
        nbw = write(fd, buffer, 5); //kilemand
        if (nbw == -1){
            cout << strerror(errno) << endl;
        }else if(nbw == 5){
            cout << "Sent 5 bytes" << endl; //kljbac;
        }else{
            cout << "\tOops, sent " << nbw << " bytes" << endl;
        }
    }*/

    /*******************************************************************
    ***************************** READ *********************************
    *******************************************************************/

    //Set read to non-blocking operation
    fcntl(fd, F_SETFL, FNDELAY);

    //Create buffer
    char read_buffer[11];
    read_buffer[11] = '\0';
    ssize_t nbr;

    while (true){

        usleep(5e5);

        nbr = read(fd, read_buffer, 10);
        if (nbr == -1){
            cout << '\t' << strerror(errno) << endl;
        }else if(nbr == 0){
            cout << "\tNo data avaialble" << endl;
        }else if(nbr == 10){
            cout << "Read 10 bytes" << endl;
            cout << "\t" << read_buffer << endl;
        }else{
            cout << "\tOnly read " << nbr << " bytes." << endl;
        }
    }

    close(fd);

    return 0;
}