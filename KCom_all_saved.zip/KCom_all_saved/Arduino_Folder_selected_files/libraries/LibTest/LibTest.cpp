#include "LibTest.h"

PrintTest::PrintTest(int iin){
	i = iin;
}

void PrintTest::begin(){
	Serial.begin(115200);
	Serial.println(String(i));
}

void PrintTest::print(){

	Serial.println("Hello World!");

}

void PrintTest::println(){
	Serial.println("This is println");
}

LibTest::LibTest(PrintTest* npt){
	pt = npt;
}

void LibTest::begin(){
	pt->begin();
	pt->print();
}

void LibTest::hello(){
	pt->println();
}
