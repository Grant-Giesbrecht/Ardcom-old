#include "Arduino.h"

class PrintTest{
public:
	PrintTest(int i);
	void begin();
	void print();
	void println();

private:
	int i;

};


class LibTest{
public:
	LibTest(PrintTest* npt);
	void begin();
	void hello();

private:

	PrintTest* pt;

};
