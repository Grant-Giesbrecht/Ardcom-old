// #include "Arduino.h"

#ifndef _AARDRF24_H_
#define _AARDRF24_H_

#include <SPI.h>
#include "RF24.h"
#include <printf.h>
#include <nRF24L01.h>
#include <RF24_config.h>

#define PACKET_SIZE 32
#define MODE_MASTER 'M'
#define MODE_SLAVE 'S'

//Error codes
#define WRITE_FAIL 0 /*Write to slave failed*/
#define SALVE_FAIL 1 /*Master fails to read salve (response from slave)*/

class AardRF24{

public:

    AardRF24(char mode, RF24& rf24_module);

    bool send_packet(char command, char parameter_1, char parameter_2, char data[29], char output[32], short* error_code);
    bool send_packet(char data[32], char output[32], short* error_code);

private:

    //Radio & radio configuration variables
    RF24& radio;
    char mode;

    //Variables
    unsigned int trial_time; // time in ms to wait for Salve

};


#endif