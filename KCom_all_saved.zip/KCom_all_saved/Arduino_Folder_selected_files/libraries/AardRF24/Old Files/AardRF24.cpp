#include "AardRF24.h"

AardRF24::AardRF24(char mode, RF24& radio_module)/* : radio(7, 8)*/{

    //Initialize variables
    trial_time = 2000;
    AardRF24::mode = mode;
    radio = radio_module;

    const uint64_t pipes[2] = { 0xABCDABCD71LL, 0x544d52687CLL };

    //Initialize radio
    if (mode == MODE_MASTER){
        if (!radio.begin()){
            return;
        }
        // radio.setChannel(1);
        // radio.setPALevel(RF24_PA_MAX);
        // radio.setDataRate(RF24_1MBPS);
        // radio.setAutoAck(1);                     // Ensure autoACK is enabled
        // radio.setRetries(2,15);                  // Optionally, increase the delay between retries & # of retries
        // radio.setCRCLength(RF24_CRC_8);          // Use 8-bit CRC for performance
        // radio.openWritingPipe(pipes[1]);
        // radio.openReadingPipe(1,pipes[0]);
        // radio.stopListening();
    }else{
        radio.begin();                           // Setup and configure rf radio
        radio.setChannel(1);
        radio.setPALevel(RF24_PA_MAX);
        radio.setDataRate(RF24_1MBPS);
        radio.setAutoAck(1);                     // Ensure autoACK is enabled
        radio.setRetries(2,15);                  // Optionally, increase the delay between retries & # of retries
        radio.setCRCLength(RF24_CRC_8);          // Use 8-bit CRC for performance
        radio.openWritingPipe(pipes[0]);
        radio.openReadingPipe(1,pipes[1]);
        radio.startListening();                 // Start listening
    }

    // radio.powerUp();
}

bool AardRF24::send_packet(char command, char parameter_1, char parameter_2, char data[29], char output[32], short* error_code){
    
    //Create packet to send
    char packet[32];
    packet[0] = command;
    packet[1] = parameter_1;
    packet[2] = parameter_2;
    for (int i = 0 ; i < 29 ; i++){ //Copy data from data buffer into packet
        packet[i+3] = data[i];
    }

    AardRF24::send_packet(packet, output, error_code);
}

bool AardRF24::send_packet(char packet[32], char output[32], short* error_code){
    
    unsigned long previous;

    if (radio.write(packet, PACKET_SIZE)){ //If write...

        radio.startListening(); // (Prepare radio for reading)

        //For 'X' amount of time...
        bool read_success = false;
        previous = millis();
        while (millis() - previous < trial_time){
            
            if (radio.available()){ //If available...
                
                radio.read(output, PACKET_SIZE); //Read

                //Break
                read_success = true;
                break;
            
            }
            
        }

        radio.stopListening(); // (Prepare radio for sending)

        if (!read_success){
            *error_code = SALVE_FAIL;
            return false;
        }

        

    }else{ //Else (write fails)...

        //Print error
        *error_code = WRITE_FAIL;
        return false;

    }

    return true;
}
