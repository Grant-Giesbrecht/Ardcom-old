#include <iostream>
#include <stdio.h>

using namespace std;

int main(){


    int a = 3;
     a += 3;
    int b = 4;

    cout << a + b << endl;

    cout << "Hello world" << endl;

    return 0;
}