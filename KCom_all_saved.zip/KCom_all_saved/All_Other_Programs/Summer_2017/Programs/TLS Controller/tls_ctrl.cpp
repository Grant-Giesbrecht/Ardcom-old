#include <iostream>
#include <string>
#include <stdio.h>
#include <vector>
#include <string.h>
#include <stdint.h>

#include "Ardcom.hpp"
#include "string_manip.hpp"
#include "stdutil.hpp"

#ifdef _WIN32
	#define USB_1 "COM1"
    #define CLEAR_CMD "CLS"
#elif __APPLE__
	//MacBook Pro USB Port Macros
	#define USB_LEFT "/dev/cu.usbmodem1411"
    #define CLEAR_CMD "clear"
#elif __linux__
	#define USB "/dev/ttyACM0"
    #define CLEAR_CMD "clear"
#else
  #error "Unknown compiler"
#endif

//MCU Parameters
#define REP_BATTERY 0
#define ACT_SERVO_FORWARD 1 // Move forward servo to specified position
#define ACT_SERVO_AFT 2 // Move aft servo to specified position
#define ACT_RUN 3 // Execute gait
#define ACT_ALL_STOP 4 // All stop

using namespace std;

// string prompt_avail_USB(string indentation);

int main(int argc, char** argv){

    cout << " -----------  THREE LINK SWIMMER CONTROLLER  ----------- " << endl;

    string port = prompt_avail_USB("");
    // string port = "/dev/ttyUSB0";

    if (port == "BAD_PORT" || port == "NO_PORTS"){
        return -1;
    }

    Ardcom mcu(port);
    if (mcu.is_open()){
        cout << "Connected to MCU on port " << port << '.' << endl;
    }else{
        cout << "ERROR: Failed to connect to MCU" << endl;
        return -1;
    }

    mcu.wait_for_MCU(3);

    if (argc > 1){
        cout << "Sending blank character" << endl;
        mcu.send_blank_char();
        mcu.send_blank_char();
        mcu.send_blank_char();
    }

    if (mcu.verify_connection()){
        cout << "MCU connection verified." << endl;
    }else{
        cout << "ERROR: MCU connection verification failed!" << endl;
        return -1;
    }

    bool running = true;
    string input, raw_input;
    vector<string> words;
    vector<string> raw_words;
    float x = -1;
    while (running){

        //Retrieve and format input
        cout << ": ";
        getline(cin, raw_input);
        if (raw_input.length() == 0) continue;
        input = to_uppercase(raw_input);

        //Parse string
        words = parse(input, " ");
        raw_words = parse(raw_input, " ");

        if (words.size() < 0){
            continue;
        }

        //Look for keywords and execute command
        if (words[0] == "HELP"){
            print_file("tls_ctrl_help.txt", 1);
        }else if(words[0] == "SET"){

        }else if(words[0] == "BAT"){
            mcu.read_MCU_parameter(REP_BATTERY, x);
            unsigned char* c;
            // for (int i = 0 ; i < sizeof(float) ; i++){
            //     c = (unsigned char*)((&x)+i);
            //     cout << "\t\t" << (int)(*c) << endl;
            // }
            unsigned char c1 = *( (unsigned char*)( (&x) ) );
            cout << "\tBattery Voltage : " << ((int)(c1))*5./255 << "V \t" << (int)c1 << endl;
        }else if(words[0] == "FSRV"){

            //Check for command line arguments
            float position;
            bool suc = false;
            if (words.size() > 1){
                 position = strtod(words[words.size()-1], &suc);
            }

            //If no position in arguments, prompt user
            while (!suc){
                cout << "\tPOSITION: ";
                string pos;
                getline(cin, pos);
                position = strtod(pos, &suc);
            }
            
            //Send command to MCU
            mcu.set_MCU_parameter(ACT_SERVO_FORWARD, position);
        }else if(words[0] == "ASRV"){

            //Check for command line arguments
            float position;
            bool suc = false;
            if (words.size() > 1){
                 position = strtod(words[words.size()-1], &suc);
            }

            //If no position in arguments, prompt user
            while (!suc){
                cout << "\tPOSITION: ";
                string pos;
                getline(cin, pos);
                position = strtod(pos, &suc);
            }
            
            //Send command to MCU
            mcu.set_MCU_parameter(ACT_SERVO_AFT, position);
        }else if(words[0] == "RUN"){
            system(CLEAR_CMD);
        }else if(words[0] == "STOP" || words[0] == "S"){
            mcu.set_MCU_parameter(ACT_ALL_STOP, x);
        }else if(words[0] == "RUN"){
            mcu.set_MCU_parameter(ACT_RUN, x);
        }else if(words[0] == "CLEAR"){
            system(CLEAR_CMD);
        }else if(words[0] == "EXIT"){
            running = false;
        }else{
            cout << "\tERORR: Unrecognized keyword '" + raw_words[0] << "'." << endl;
        }
    }

    cout << "Exiting" << endl;

    mcu.close();
    return 0;
}










/*****************************************************************************************
*************************************** FUNCTIONS ****************************************
*****************************************************************************************/


// string prompt_avail_USB(string indentation){

//     string input;

//     //Find available USB ports
// 	vector<string> ports;
// 	Ardcom test0;
// 	if (test0.open("/dev/ttyUSB0")){
// 		ports.push_back("/dev/ttyUSB0");
// 		test0.close();
// 	}


// 	Ardcom test1;
// 	if (test1.open("/dev/ttyUSB1")){
// 		ports.push_back("/dev/ttyUSB1");
// 		test1.close();
// 	}

//     Ardcom test4;
// 	if (test4.open("/dev/ttyUSB2")){
// 		ports.push_back("/dev/ttyUSB2");
// 		test4.close();
// 	}


// 	Ardcom test2;
// 	if (test2.open("/dev/ttyACM0")){
// 		ports.push_back("/dev/ttyACM0");
// 		test2.close();
// 	}


// 	Ardcom test3;
// 	if (test3.open("/dev/ttyACM1")){
// 		ports.push_back("/dev/ttyACM1");
// 		test3.close();
// 	}

//     Ardcom test5;
// 	if (test5.open("/dev/ttyACM2")){
// 		ports.push_back("/dev/ttyACM2");
// 		test5.close();
// 	}

// 	//List available ports and read user selection
// 	if (ports.size() == 0){
// 		cout << indentation << "No devices found." << endl;
// 		return "NO_PORT";
// 	}

// 	//Propmt user to select port
//     cout << indentation << "Select a port to which to attach..." << endl;
// 	int a;
//     bool success;
// 	do{
// 		for (int i = 0 ; i < ports.size() ; i++){
// 			cout << i << "). " << ports[i] << endl;
// 		}
// 		cout << indentation << endl << "Port: ";
// 		getline(cin, input);
//         if (input == "x" || input == "X") break;
//         a = (int)strtod(input, &success);
//         if (!success) continue;
// 	}while(a >= ports.size());

// 	//Check if user entered x (to exit)
// 	if (input == "x"){
// 		cout << indentation << "Exiting" << endl;
// 		return "BAD_PORT";
// 	}

//     return ports[a];
// }
