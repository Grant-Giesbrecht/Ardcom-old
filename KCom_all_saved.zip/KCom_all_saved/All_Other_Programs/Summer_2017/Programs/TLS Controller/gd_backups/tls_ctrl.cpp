#include <iostream>
#include <string>
#include <stdio.h>
#include <vector>

using namespace std;

string prompt_avail_USB(string indentation);

int main(int argc, char** argv){

    cout << " -----------  THREE LINK SWIMMER CONTROLLER  ----------- " << endl;


    return 0;
}

string prompt_avail_USB(string indentation){

    //Find available USB ports
	vector<string> ports;
	Ardcom test0;
	if (test0.open("/dev/ttyUSB0")){
		ports.push_back("/dev/ttyUSB0");
		test0.close();
	}


	Ardcom test1;
	if (test1.open("/dev/ttyUSB1")){
		ports.push_back("/dev/ttyUSB1");
		test1.close();
	}

    Ardcom test4;
	if (test4.open("/dev/ttyUSB2")){
		ports.push_back("/dev/ttyUSB2");
		test4.close();
	}


	Ardcom test2;
	if (test2.open("/dev/ttyACM0")){
		ports.push_back("/dev/ttyACM0");
		test2.close();
	}


	Ardcom test3;
	if (test3.open("/dev/ttyACM1")){
		ports.push_back("/dev/ttyACM1");
		test3.close();
	}

    Ardcom test5;
	if (test5.open("/dev/ttyACM2")){
		ports.push_back("/dev/ttyACM2");
		test5.close();
	}

	//List available ports and read user selection
	if (ports.size() == 0){
		cout << indentation << "No devices found." << endl;
		return -1;
	}

	//Propmt user to select port
	int a;
	do{
		for (int i = 0 ; i < ports.size() ; i++){
			cout << i << "). " << ports[i] << endl;
		}
		cout << indentation << endl << "Port: ";
		cin >> a;
	}while(a >= ports.size());

	//Check if user entered -1 (to exit)
	if (a < 0){
		cout << indentation << "Exiting" << endl;
		return "BAD_PORT";
	}

    return ports[a];
}