#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>
#include "Ardcom.hpp"

using namespace std;

int main(){

    string port = prompt_avail_USB("");

    if (port == "BAD_PORT" || port == "NO_PORTS"){
        return -1;
    }

    Ardcom mcu(port);
    if (mcu.is_open()){
        cout << "Connected to MCU on port " << port << '.' << endl;
    }else{
        cout << "ERROR: Failed to connect to MCU" << endl;
        return -1;
    }

    mcu.wait_for_MCU(2);

    if (mcu.verify_connection()){
        cout << "Connection verified" << endl;
    }else{
        cout << "Connection verification failed" << endl;
    }

    return 0;
}