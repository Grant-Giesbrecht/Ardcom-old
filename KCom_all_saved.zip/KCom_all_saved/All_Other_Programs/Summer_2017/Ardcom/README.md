# Ardcom
Arduino/C++ Interface

This library allows a user to communicate with an Arduino via USB using C++.
