//
//  ArdcomMain.cpp
//
//
//  Created by Grant Giesbrecht on 6/29/17.
//
//

#include <stdio.h>
#include "Ardcom.hpp"
#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include <string>
#include <vector>

using namespace std;

int main(){

	//Find available USB ports
	vector<string> ports;
	Ardcom test0;
	if (test0.open("/dev/ttyUSB0")){
		ports.push_back("/dev/ttyUSB0");
		test0.close();
	}


	Ardcom test1;
	if (test1.open("/dev/ttyUSB1")){
		ports.push_back("/dev/ttyUSB1");
		test1.close();
	}


	Ardcom test2;
	if (test2.open("/dev/ttyACM0")){
		ports.push_back("/dev/ttyACM0");
		test2.close();
	}


	Ardcom test3;
	if (test3.open("/dev/ttyACM1")){
		ports.push_back("/dev/ttyACM1");
		test3.close();
	}


    // Ardcom mcu(USB_ALT);
    // if (!mcu.is_open()){
    //     cout << "ERROR: Failed to connect to MCU on port " << USB_RIGHT << endl;
    //     return 1;
    // }

	//List available ports and read user selection
	if (ports.size() == 0){
		cout << "No devices found." << endl;
		return -1;
	}

	//Propmt user to select port
	int a;
	do{
		for (int i = 0 ; i < ports.size() ; i++){
			cout << i << "). " << ports[i] << endl;
		}
		cout << endl << "Port: ";
		cin >> a;
	}while(a >= ports.size());

	//Check if user entered -1 (to exit)
	if (a < 0){
		cout << "Exiting" << endl;
		return -1;
	}

	//Connect to selected port
	Ardcom mcu(ports[a]);
    if (!mcu.is_open()){
        cout << "ERROR: Failed to connect to MCU on port " << ports[a] << endl;
        return -1;
    }

    mcu.wait_for_MCU(2); //12 for Arduino 101

	char x;
	while (true){
		mcu.recieve_char(x);
		cout << x << std::flush;
	}

	//
    // float x;
	//
    // mcu.read_MCU_parameter(0x01, x);
    // cout << "Read value: " << x << endl;
	//
    // mcu.set_MCU_parameter(0x01, 14.2);
	//
    // mcu.read_MCU_parameter(0x01, x);
    // cout << "Read value: " << x << endl;
	//
    // float y;
	//
    // while (true){
	//
    //     x = (rand() % 10000)/100; //generate random number
	//
    //     //Ping float to MCU and print values
    //     cout << "Float sent to MCU: " << to_string(x) << "\t * 7 = " << to_string(x*7) << endl;
    //     mcu.ping_float(0x01, x, y);
    //     cout << "\tFloat recieved from MCU: " << to_string(y) << endl;
	//
    //     usleep(100000); //delay
	//
    // }

    return 0;
}
